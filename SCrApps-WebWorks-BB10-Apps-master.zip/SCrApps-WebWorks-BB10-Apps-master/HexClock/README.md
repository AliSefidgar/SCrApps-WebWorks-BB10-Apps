Hex Clock
======

Hex Clock is a fairly simple concept: a clock that is colored to match the corresponding hexadecimal color.
For example, at 19:40:00 (7:40 PM), Hex Clock will be the color #194000, which is a dark green.
The background of Hex Clock will take the opposite value.

Changes in Version 1.1:
In version 1.1 Hex Clock was paired with bbUI (https://github.com/blackberry/bbUI.js) and became a BlackBerry App.
It also became an example of BBM Integration for BlackBerry 10.
The original v1.0, which is capable of running in any browser, has been retained.

License:
Hex Clock is licensed under the Apache Open Source License.