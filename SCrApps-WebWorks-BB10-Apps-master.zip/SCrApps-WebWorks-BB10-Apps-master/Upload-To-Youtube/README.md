Upload-To-YouTube
====================

The Upload To YouTube app is an example of how to leverage the native BlackBerry File Picker and YouTube Video Upload APIs.
It also demonstrates how to make your BlackBerry 10 app invocable by other apps.

Dependencies:
bbUI (inluded)

License:
This code is released under an Apache Open Source license. It can always be downloaded for free from https://www.github.com/SCrid2000

Privacy:
As you can see if you check the source code, this app doesn't save or transmit any personal information; if by any strange chance I get any of your information (excluding, of course, your email address if you contact me with a question) I'll delete it, as I have no use for it. I don't want your personal information, I'm not Google.