Compose
======

Compose demonstrates how to invoke the email composer card (https://developer.blackberry.com/html5/apis/blackberry.invoke.card.html#.invokeEmailComposer) in a WebWorks application.
It also simulates the BlackBerry 10 loading spinner.

License:
Compose is licensed under the Apache Open Source License.