JSCalc
======

A Calculator written in Javascript.

Changes in Version 1.1:
In version 1.1 JSCalc was paired with bbUI (https://github.com/blackberry/bbUI.js) and became a BlackBerry App.
It also became an example of BBM Integration for BlackBerry 10.
The original v1.0, which is capable of running in any browser, has been retained.

License:
JSCalc is licensed under the Apache Open Source License.