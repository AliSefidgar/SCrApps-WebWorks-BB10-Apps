KISSBBM
=======

KISS (Keep It Simple Stupid) BBM Integration Sample App for BlackBerry 10.

This app makes it easy to add BBM Integration to your WebWorks app.

Credits
This sample wouldn't have been possible without the totally awesome bbUI project (https://github.com/blackberry/bbUI.js), the pre-existing BBM sample by Erik Oros (https://github.com/oros), and of course the hard work by the entire WebWorks team.

Truthfully, Erik's sample is much more impressive than this one, and contains several features that I didn't bother including. However, I think this sample is easier to rip the needed code from and drop it into your own app. I spent several hours figuring out how Erik's sample worked before I was able to make this one (although that's more a reflection on my nonexistant formal code learning than a reflection on the difficulty of Erik's sample). This sample is geared more towards helping the newest developer can quickly and easily integrate BBM with their BB10 apps.

License:
This code is released under an Apache Open Source license. It can always be downloaded for free from https://www.github.com/SCrid2000

Privacy:
As you can see if you check the source code, this app doesn't save or transmit any personal information; if by any strange chance I get any of your information (excluding, of course, your email address if you contact me with a question) I'll delete it, as I have no use for it. I don't want your personal information, I'm not Google.