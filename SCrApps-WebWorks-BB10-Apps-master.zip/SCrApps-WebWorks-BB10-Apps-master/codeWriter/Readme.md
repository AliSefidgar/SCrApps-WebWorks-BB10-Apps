codeWriter
====================

I made this app for testing scraps of HTML, JavaScript, or CSS code when I'm out and about and don't have a PC handy.<br><br>
It's built using CodeMirror, which is an excellent Open Source HTML based code editing programming API. 
CodeMirror can be found at http://codemirror.net/.

Any code enter here will automatically be saved into localStorage, so when you open the app you'll be right back where you started. If you don't have any data saved in the html field above, this screen will be displayed.

Version 1.0 doesn't contain much more than a text field and a WYSIWYG display; in future releases I hope to add export to file, theming options, and other useful updates.