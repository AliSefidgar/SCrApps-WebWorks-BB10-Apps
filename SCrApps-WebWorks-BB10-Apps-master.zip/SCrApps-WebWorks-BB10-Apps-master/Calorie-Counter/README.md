Calorie Counter
====================

Calorie Counter is an example of how to save some data to the BlackBerry Calendar in BlackBerry 10.